package com.xy.lifemanage.utils;

/**
 * Created by nemo on 2016/5/9 0009.
 */
public class HttpUtils {
    public static final String APP_ID = "094ac60dcb8bd8bdeb2a8580b9b259ec";
}
