package com.xy.lifemanage.bean;

/**
 * Created by nemo on 2016/5/10 0010.
 */
public class Bean {
}
