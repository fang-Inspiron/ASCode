package com.xy.lifemanage.app;

import android.app.Application;

/**
 * Created by nemo on 2016/5/10 0010.
 */
public class App extends Application{

}
